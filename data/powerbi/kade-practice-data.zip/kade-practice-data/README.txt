Kade Distribution: practice data for the Power BI course
=========================================================
Kade Distribution is a made-up Dutch wholesaler. Everything in these files is generated for practice; no real
company, customer or person is in them. Extracted on 31-12-2025.

Orders.csv      one row per order line, Jan 2024 - Dec 2025. A Dutch export: fields split by ";", decimals with ",",
                dates as dd-mm-yyyy. Some rows came out twice, and a few are test orders (CustomerID TEST).
                Lines not yet delivered on the extract date have no ShipDate, DeliveredDate, QtyShipped or FreightEUR.
Customers.csv   60 customers in the Netherlands, Belgium and Germany, and the warehouse that serves each.
Products.csv    40 products (sold per carton), their category, supplier, price, cost and carton weight.
Suppliers.csv, Carriers.csv, Warehouses.csv   the lookups.

Definitions the course uses
  Delivered line   DeliveredDate is filled in.
  On time          DeliveredDate is on or before RequestedDate.
  In full          QtyShipped is at least QtyOrdered.
  OTIF %           delivered lines that are on time AND in full, divided by delivered lines.
  Fill rate        cartons shipped divided by cartons ordered, on delivered lines.
  Revenue          QtyShipped x UnitPriceEUR.     Kg shipped   QtyShipped x CartonWeightKg.
